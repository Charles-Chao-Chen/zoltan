siMPI was developed by Pat Miller at Lawrence Livermore 
National Laboratory.  It is distributed as part of pyMPI at
http://sourceforge.net/projects/pympi/ .  With permission of the author,
Zoltan uses siMPI to satisfy MPI dependencies for serial builds of Trilinos.

siMPI is not owned, copyrighted, licensed, developed or supported by Sandia 
National Laboratories or the Trilinos project.  

siMPI is third-party software that does not fall under Trilinos' or 
Zoltan's license.
